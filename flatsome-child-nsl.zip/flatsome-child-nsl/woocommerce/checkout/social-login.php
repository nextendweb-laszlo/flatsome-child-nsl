<div class="text-left social-login pb-half pt-half">
    <?php
    if (class_exists('NextendSocialLogin', false)) {
        echo do_shortcode('[nextend_social_login style="grid" align="center"]');
    }
    ?>
</div>
